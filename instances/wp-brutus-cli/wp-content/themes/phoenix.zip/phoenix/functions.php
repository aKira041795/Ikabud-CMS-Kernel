<?php
/**
 * Phoenix Theme Functions
 * 
 * DiSyL-powered WordPress theme with advanced features
 * 
 * @package Phoenix
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Disable error display for AJAX to prevent JSON corruption
if (defined('DOING_AJAX') && DOING_AJAX) {
    @ini_set('display_errors', 0);
    @error_reporting(0);
}

// ROOT CAUSE FIX: Disable block-based widget editor to use classic editor
// The block editor conflicts with classic widgets that use wp_enqueue_editor() (like Text widget)
add_filter('use_widgets_block_editor', '__return_false');

/**
 * Load Phoenix Bridge Layer
 * Connects DiSyL components with WordPress Customizer
 */
require_once get_template_directory() . '/includes/class-phoenix-manifest.php';
require_once get_template_directory() . '/includes/class-phoenix-customizer.php';
require_once get_template_directory() . '/includes/class-phoenix-component-bridge.php';
require_once get_template_directory() . '/includes/phoenix-template-functions.php';

/**
 * Theme Setup
 */
function phoenix_setup() {
    // Add theme support
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('automatic-feed-links');
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('custom-background');
    add_theme_support('customize-selective-refresh-widgets');
    
    // Register navigation menus
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'phoenix'),
        'footer'  => __('Footer Menu', 'phoenix'),
        'social'  => __('Social Links', 'phoenix'),
    ));
    
    // Add image sizes
    add_image_size('phoenix-hero', 1920, 1080, true);
    add_image_size('phoenix-featured', 800, 600, true);
    add_image_size('phoenix-thumbnail', 400, 300, true);
    add_image_size('phoenix-slider', 1600, 900, true);
}
add_action('after_setup_theme', 'phoenix_setup');

/**
 * Register Widget Areas
 */
function phoenix_widgets_init() {
    // Sidebar
    register_sidebar(array(
        'name'          => __('Main Sidebar', 'phoenix'),
        'id'            => 'sidebar-1',
        'description'   => __('Main sidebar widget area', 'phoenix'),
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
    
    // Footer widgets (4 columns)
    for ($i = 1; $i <= 4; $i++) {
        register_sidebar(array(
            'name'          => sprintf(__('Footer Widget %d', 'phoenix'), $i),
            'id'            => 'footer-' . $i,
            'description'   => sprintf(__('Footer widget area %d', 'phoenix'), $i),
            'before_widget' => '<div id="%1$s" class="footer-widget %2$s">',
            'after_widget'  => '</div>',
            'before_title'  => '<h3 class="widget-title">',
            'after_title'   => '</h3>',
        ));
    }
    
    // Homepage widgets
    register_sidebar(array(
        'name'          => __('Homepage Hero', 'phoenix'),
        'id'            => 'homepage-hero',
        'description'   => __('Homepage hero section widgets', 'phoenix'),
        'before_widget' => '<div id="%1$s" class="hero-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h2 class="widget-title">',
        'after_title'   => '</h2>',
    ));
    
    register_sidebar(array(
        'name'          => __('Homepage Features', 'phoenix'),
        'id'            => 'homepage-features',
        'description'   => __('Homepage features section widgets', 'phoenix'),
        'before_widget' => '<div id="%1$s" class="feature-widget %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3 class="widget-title">',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'phoenix_widgets_init');

/**
 * Enqueue Scripts and Styles
 */
function phoenix_scripts() {
    // DiSyL components stylesheet (load first)
    wp_enqueue_style('disyl-components', get_template_directory_uri() . '/assets/css/disyl-components.css', array(), '0.4.0');
    
    // Theme stylesheet
    wp_enqueue_style('phoenix-style', get_stylesheet_uri(), array('disyl-components'), '1.0.0');
    
    // Custom JavaScript
    wp_enqueue_script('phoenix-scripts', get_template_directory_uri() . '/assets/js/phoenix.js', array(), '1.0.0', true);
    
    // Localize script - use current domain for AJAX to avoid CORS
    $current_domain = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http') . '://' . $_SERVER['HTTP_HOST'];
    wp_localize_script('phoenix-scripts', 'phoenixData', array(
        'ajaxurl' => $current_domain . '/wp-admin/admin-ajax.php',
        'nonce'   => wp_create_nonce('phoenix-nonce'),
    ));
    
    // Comment reply script
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'phoenix_scripts');

// CORS and domain fixes moved to /wp-content/mu-plugins/ikabud-disyl-integration.php

/**
 * Enable DiSyL support for this theme
 * Core DiSyL rendering handled by /wp-content/mu-plugins/ikabud-disyl-integration.php
 */
add_theme_support('ikabud-disyl');

/**
 * Extend DiSyL context with theme-specific data
 * Hook into the base context provided by the MU plugin
 */
function phoenix_extend_disyl_context($context) {
    // Add menu data
    $context['menu'] = array(
        'primary' => phoenix_get_menu_items('primary'),
        'footer' => phoenix_get_menu_items('footer'),
        'social' => phoenix_get_menu_items('social'),
    );
    
    // Add widget areas
    $context['widgets'] = array(
        'main_sidebar' => phoenix_get_widget_area('sidebar-1'),
        'footer_1' => phoenix_get_widget_area('footer-1'),
        'footer_2' => phoenix_get_widget_area('footer-2'),
        'footer_3' => phoenix_get_widget_area('footer-3'),
        'footer_4' => phoenix_get_widget_area('footer-4'),
        'homepage_hero' => phoenix_get_widget_area('homepage-hero'),
        'homepage_features' => phoenix_get_widget_area('homepage-features'),
    );
    
    // Add category context if on category page
    if (is_category()) {
        try {
            $context['category'] = phoenix_get_category_context();
        } catch (Exception $e) {
            error_log('Phoenix Category Context Error: ' . $e->getMessage());
            $context['category'] = array();
        }
    }
    
    // Add tag context if on tag page
    if (is_tag()) {
        $context['tag'] = phoenix_get_tag_context();
    }
    
    return $context;
}
add_filter('ikabud_disyl_context', 'phoenix_extend_disyl_context');

// Base context building moved to /wp-content/mu-plugins/ikabud-disyl-integration.php
// Theme extends context via 'ikabud_disyl_context' filter (see phoenix_extend_disyl_context above)

/**
 * Custom Excerpt Length
 */
function phoenix_excerpt_length($length) {
    return 30;
}
add_filter('excerpt_length', 'phoenix_excerpt_length');

/**
 * Custom Excerpt More
 */
function phoenix_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'phoenix_excerpt_more');

/**
 * Add custom classes to body
 */
function phoenix_body_classes($classes) {
    if (!is_singular()) {
        $classes[] = 'hfeed';
    }
    
    if (is_active_sidebar('sidebar-1')) {
        $classes[] = 'has-sidebar';
    }
    
    return $classes;
}
add_filter('body_class', 'phoenix_body_classes');

/**
 * Get Menu Items for DiSyL Context
 */
function phoenix_get_menu_items($location) {
    $locations = get_nav_menu_locations();
    
    // Check if menu location has a menu assigned
    if (!isset($locations[$location])) {
        return phoenix_get_fallback_menu($location);
    }
    
    $menu = wp_get_nav_menu_object($locations[$location]);
    
    if (!$menu) {
        return phoenix_get_fallback_menu($location);
    }
    
    $menu_items = wp_get_nav_menu_items($menu->term_id);
    
    if (!$menu_items) {
        return phoenix_get_fallback_menu($location);
    }
    
    // Build hierarchical menu structure properly
    return phoenix_build_menu_tree($menu_items, 0);
}

/**
 * Build hierarchical menu tree recursively
 * CMS-agnostic approach using pure value copying (no references)
 */
function phoenix_build_menu_tree($menu_items, $parent_id = 0) {
    $branch = array();
    
    foreach ($menu_items as $item) {
        // WordPress stores parent as string, convert for comparison
        $item_parent = (int)$item->menu_item_parent;
        
        if ($item_parent == $parent_id) {
            // Recursively get children first
            $children = phoenix_build_menu_tree($menu_items, $item->ID);
            
            // Build classes array
            $classes = $item->classes;
            if (!empty($children)) {
                $classes[] = 'has-submenu';
            }
            
            // Create menu item array
            $menu_item = array(
                'id' => $item->ID,
                'title' => $item->title,
                'url' => $item->url,
                'target' => $item->target,
                'classes' => implode(' ', $classes),
                'active' => ($item->url === home_url($_SERVER['REQUEST_URI'])),
                'parent_id' => $item->menu_item_parent,
                'order' => $item->menu_order,
                'children' => $children,
            );
            
            $branch[] = $menu_item;
        }
    }
    
    return $branch;
}

/**
 * Get Category Context for DiSyL
 * CMS-agnostic structure for category/taxonomy pages
 */
function phoenix_get_category_context() {
    $category = get_queried_object();
    
    if (!$category || !isset($category->term_id)) {
        return array();
    }
    
    // Get parent category if exists
    $parent = null;
    if ($category->parent) {
        $parent_cat = get_category($category->parent);
        $parent = array(
            'id' => $parent_cat->term_id,
            'name' => $parent_cat->name,
            'slug' => $parent_cat->slug,
            'url' => get_category_link($parent_cat->term_id),
            'count' => $parent_cat->count,
        );
    }
    
    // Get child categories
    $children = array();
    $child_cats = get_categories(array(
        'parent' => $category->term_id,
        'hide_empty' => false,
    ));
    
    foreach ($child_cats as $child) {
        $children[] = array(
            'id' => $child->term_id,
            'name' => $child->name,
            'slug' => $child->slug,
            'url' => get_category_link($child->term_id),
            'description' => $child->description,
            'count' => $child->count,
            'image' => phoenix_get_term_image($child->term_id),
        );
    }
    
    // Get related categories (siblings)
    $related = array();
    if ($category->parent) {
        $siblings = get_categories(array(
            'parent' => $category->parent,
            'exclude' => $category->term_id,
            'hide_empty' => false,
            'number' => 5,
        ));
        
        foreach ($siblings as $sibling) {
            $related[] = array(
                'id' => $sibling->term_id,
                'name' => $sibling->name,
                'slug' => $sibling->slug,
                'url' => get_category_link($sibling->term_id),
                'count' => $sibling->count,
            );
        }
    }
    
    return array(
        'id' => $category->term_id,
        'name' => $category->name,
        'slug' => $category->slug,
        'description' => $category->description,
        'url' => get_category_link($category->term_id),
        'count' => $category->count,
        'image' => phoenix_get_term_image($category->term_id),
        'parent' => $parent,
        'children' => $children,
        'related' => $related,
    );
}

/**
 * Get Tag Context for DiSyL
 * CMS-agnostic structure for tag pages
 */
function phoenix_get_tag_context() {
    $tag = get_queried_object();
    
    if (!$tag || !isset($tag->term_id)) {
        return array();
    }
    
    // Get related tags (by post overlap)
    $related = array();
    $related_tags = get_tags(array(
        'exclude' => $tag->term_id,
        'number' => 10,
        'orderby' => 'count',
        'order' => 'DESC',
    ));
    
    foreach ($related_tags as $rtag) {
        $related[] = array(
            'id' => $rtag->term_id,
            'name' => $rtag->name,
            'slug' => $rtag->slug,
            'url' => get_tag_link($rtag->term_id),
            'count' => $rtag->count,
        );
    }
    
    return array(
        'id' => $tag->term_id,
        'name' => $tag->name,
        'slug' => $tag->slug,
        'description' => $tag->description,
        'url' => get_tag_link($tag->term_id),
        'count' => $tag->count,
        'related' => $related,
    );
}

// Pagination context moved to MU plugin base context

/**
 * Get Term Image (for category/tag images)
 * Uses WordPress term meta or returns null
 */
function phoenix_get_term_image($term_id) {
    // Check for common term meta keys
    $image_keys = array('thumbnail_id', 'image', 'category_image');
    
    foreach ($image_keys as $key) {
        $image_id = get_term_meta($term_id, $key, true);
        if ($image_id) {
            $image_url = wp_get_attachment_image_url($image_id, 'medium');
            if ($image_url) {
                return $image_url;
            }
        }
    }
    
    return null;
}

/**
 * Get Fallback Menu Items (when no menu is assigned)
 */
function phoenix_get_fallback_menu($location) {
    // Only provide fallback for primary menu
    if ($location !== 'primary') {
        return array();
    }
    
    // Default menu items
    return array(
        array(
            'id' => 0,
            'title' => 'Home',
            'url' => home_url('/'),
            'target' => '',
            'classes' => 'menu-item',
            'active' => is_front_page(),
            'parent_id' => 0,
            'order' => 1,
        ),
        array(
            'id' => 0,
            'title' => 'Blog',
            'url' => home_url('/blog'),
            'target' => '',
            'classes' => 'menu-item',
            'active' => is_home(),
            'parent_id' => 0,
            'order' => 2,
        ),
    );
}

/**
 * Custom Walker for Navigation Menu
 */
class Phoenix_Walker_Nav_Menu extends Walker_Nav_Menu {
    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0) {
        $classes = empty($item->classes) ? array() : (array) $item->classes;
        $classes[] = 'menu-item-' . $item->ID;
        
        if ($item->current) {
            $classes[] = 'active';
        }
        
        $class_names = join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args, $depth));
        $class_names = $class_names ? ' class="' . esc_attr($class_names) . '"' : '';
        
        $output .= '<li' . $class_names . '>';
        
        $atts = array();
        $atts['href'] = !empty($item->url) ? $item->url : '';
        $atts = apply_filters('nav_menu_link_attributes', $atts, $item, $args, $depth);
        
        $attributes = '';
        foreach ($atts as $attr => $value) {
            if (!empty($value)) {
                $attributes .= ' ' . $attr . '="' . esc_attr($value) . '"';
            }
        }
        
        $item_output = $args->before;
        $item_output .= '<a' . $attributes . '>';
        $item_output .= $args->link_before . apply_filters('the_title', $item->title, $item->ID) . $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;
        
        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }
}

/**
 * AJAX Load More Posts
 */
function phoenix_load_more_posts() {
    check_ajax_referer('phoenix-nonce', 'nonce');
    
    $paged = isset($_POST['page']) ? intval($_POST['page']) : 1;
    
    $args = array(
        'post_type' => 'post',
        'posts_per_page' => 6,
        'paged' => $paged,
    );
    
    $query = new WP_Query($args);
    
    if ($query->have_posts()) {
        ob_start();
        while ($query->have_posts()) {
            $query->the_post();
            get_template_part('disyl/components/post', 'card');
        }
        $html = ob_get_clean();
        wp_reset_postdata();
        
        wp_send_json_success(array(
            'html' => $html,
            'has_more' => $paged < $query->max_num_pages,
        ));
    } else {
        wp_send_json_error(array('message' => 'No more posts'));
    }
}
add_action('wp_ajax_phoenix_load_more', 'phoenix_load_more_posts');
add_action('wp_ajax_nopriv_phoenix_load_more', 'phoenix_load_more_posts');

/**
 * Get widget area content
 * 
 * NOTE: For visibility-aware widget areas, use phoenix_get_widget_area_safe()
 * from includes/phoenix-template-functions.php
 */
function phoenix_get_widget_area($sidebar_id) {
    $is_active = is_active_sidebar($sidebar_id);
    
    // Debug: Log widget status
    error_log("Widget Area: $sidebar_id | Active: " . ($is_active ? 'YES' : 'NO'));
    
    if (!$is_active) {
        return array(
            'active' => false,
            'content' => '',
            'visible' => true, // Default visible if not controlled by customizer
        );
    }
    
    // Capture widget output
    ob_start();
    dynamic_sidebar($sidebar_id);
    $content = ob_get_clean();
    
    // Debug: Log content length
    error_log("Widget Area: $sidebar_id | Content Length: " . strlen($content));
    
    return array(
        'active' => true,
        'content' => $content,
        'visible' => true, // Default visible if not controlled by customizer
    );
}

/**
 * Legacy Customizer additions (kept for backward compatibility)
 * 
 * NOTE: Most customizer controls are now auto-generated from manifest.json
 * via the Phoenix_Customizer class. This function only adds legacy settings
 * that existed before the bridge layer was implemented.
 */
function phoenix_customize_register($wp_customize) {
    // Legacy settings are now handled by Phoenix_Customizer class
    // This function is kept for backward compatibility only
    
    // Hero section settings are now in manifest.json under customizer.sections.colors
    // Color settings are now in manifest.json under customizer.sections.colors
    
    // If you need to add custom settings not in manifest.json, add them here
}
add_action('customize_register', 'phoenix_customize_register', 30);
