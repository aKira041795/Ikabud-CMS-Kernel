<?php

namespace Drupal\core_fake\Driver\Database\CoreFakeWithAllCustomClasses;

use Drupal\Core\Database\Query\Update as QueryUpdate;

/**
 * CoreFakeWithAllCustomClasses implementation of \Drupal\Core\Database\Update.
 */
class Update extends QueryUpdate {

}
