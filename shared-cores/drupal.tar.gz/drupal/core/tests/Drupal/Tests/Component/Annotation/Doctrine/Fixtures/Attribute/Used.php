<?php

namespace Drupal\Tests\Component\Annotation\Doctrine\Fixtures\Attribute;

use Drupal\Tests\Component\Annotation\Doctrine\Fixtures\ExtraAttributes\ExampleAttribute;

#[/* Comment */ExampleAttribute]
final class Used
{
}
