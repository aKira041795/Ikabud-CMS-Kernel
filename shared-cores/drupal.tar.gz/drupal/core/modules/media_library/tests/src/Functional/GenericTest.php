<?php

declare(strict_types=1);

namespace Drupal\Tests\media_library\Functional;

use Drupal\Tests\system\Functional\Module\GenericModuleTestBase;

/**
 * Generic module test for media_library.
 *
 * @group media_library
 */
class GenericTest extends GenericModuleTestBase {}
