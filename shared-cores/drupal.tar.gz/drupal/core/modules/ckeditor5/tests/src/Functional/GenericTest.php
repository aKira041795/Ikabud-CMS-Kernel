<?php

declare(strict_types=1);

namespace Drupal\Tests\ckeditor5\Functional;

use Drupal\Tests\system\Functional\Module\GenericModuleTestBase;

/**
 * Generic module test for ckeditor5.
 *
 * @group ckeditor5
 */
class GenericTest extends GenericModuleTestBase {}
