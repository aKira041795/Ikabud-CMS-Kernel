<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'yao', 'yu', 'chong', 'xi', 'xi', 'jiu', 'yu', 'yu', 'xing', 'ju', 'jiu', 'xin', 'she', 'she', 'she', 'jiu',
  0x10 => 'shi', 'tan', 'shu', 'shi', 'tian', 'tan', 'pu', 'pu', 'guan', 'hua', 'tian', 'chuan', 'shun', 'xia', 'wu', 'zhou',
  0x20 => 'dao', 'chuan', 'shan', 'yi', 'fan', 'pa', 'tai', 'fan', 'ban', 'chuan', 'hang', 'fang', 'ban', 'bi', 'lu', 'zhong',
  0x30 => 'jian', 'cang', 'ling', 'zhu', 'ze', 'duo', 'bo', 'xian', 'ge', 'chuan', 'xia', 'lu', 'qiong', 'pang', 'xi', 'kua',
  0x40 => 'fu', 'zao', 'feng', 'li', 'shao', 'yu', 'lang', 'ting', 'yu', 'wei', 'bo', 'meng', 'nian', 'ju', 'huang', 'shou',
  0x50 => 'ke', 'bian', 'mu', 'die', 'dou', 'bang', 'cha', 'yi', 'sou', 'cang', 'cao', 'lou', 'dai', 'xue', 'yao', 'chong',
  0x60 => 'deng', 'dang', 'qiang', 'lu', 'yi', 'ji', 'jian', 'huo', 'meng', 'qi', 'lu', 'lu', 'chan', 'shuang', 'gen', 'liang',
  0x70 => 'jian', 'jian', 'se', 'yan', 'fu', 'ping', 'yan', 'yan', 'cao', 'cao', 'yi', 'le', 'ting', 'jiao', 'ai', 'nai',
  0x80 => 'tiao', 'jiao', 'jie', 'peng', 'wan', 'yi', 'chai', 'mian', 'mi', 'gan', 'qian', 'yu', 'yu', 'shao', 'qiong', 'du',
  0x90 => 'hu', 'qi', 'mang', 'zi', 'hui', 'sui', 'zhi', 'xiang', 'pi', 'fu', 'tun', 'wei', 'wu', 'zhi', 'qi', 'shan',
  0xA0 => 'wen', 'qian', 'ren', 'fu', 'kou', 'jie', 'lu', 'xu', 'ji', 'qin', 'qi', 'yan', 'fen', 'ba', 'rui', 'xin',
  0xB0 => 'ji', 'hua', 'hua', 'fang', 'wu', 'jue', 'gou', 'zhi', 'yun', 'qin', 'ao', 'chu', 'mao', 'ya', 'fei', 'reng',
  0xC0 => 'hang', 'cong', 'yin', 'you', 'bian', 'yi', 'qie', 'wei', 'li', 'pi', 'e', 'xian', 'chang', 'cang', 'zhu', 'su',
  0xD0 => 'ti', 'yuan', 'ran', 'ling', 'tai', 'shao', 'di', 'miao', 'qing', 'li', 'yong', 'ke', 'mu', 'bei', 'bao', 'gou',
  0xE0 => 'min', 'yi', 'yi', 'ju', 'pie', 'ruo', 'ku', 'ning', 'ni', 'bo', 'bing', 'shan', 'xiu', 'yao', 'xian', 'ben',
  0xF0 => 'hong', 'ying', 'zha', 'dong', 'ju', 'die', 'nie', 'gan', 'hu', 'ping', 'mei', 'fu', 'sheng', 'gu', 'bi', 'wei',
];
