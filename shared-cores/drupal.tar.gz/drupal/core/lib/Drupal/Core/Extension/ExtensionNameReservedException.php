<?php

namespace Drupal\Core\Extension;

/**
 * Exception thrown when the extension's name is already reserved.
 */
class ExtensionNameReservedException extends \Exception {}
