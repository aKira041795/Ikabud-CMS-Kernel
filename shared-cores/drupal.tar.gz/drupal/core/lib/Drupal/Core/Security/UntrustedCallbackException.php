<?php

namespace Drupal\Core\Security;

/**
 * Exception thrown if a callback is untrusted.
 */
class UntrustedCallbackException extends \RuntimeException {
}
