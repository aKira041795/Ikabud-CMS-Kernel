WHAT IS THIS DIRECTORY FOR?
--------------------------------
This directory is for image files previously inherited from the Classy theme.

WHY WERE CLASSY IMAGE FILES COPIED HERE?
-------------------------------------------
Classy was removed in Drupal 10. To prepare for Classy's removal, image files
that would otherwise be inherited from Classy were copied here.
