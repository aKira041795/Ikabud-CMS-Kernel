WHAT IS THIS DIRECTORY FOR?
--------------------------------
This directory is for JS files previously inherited from the Classy theme.

WHY WERE CLASSY JS FILES COPIED HERE?
-------------------------------------------
Classy was removed in Drupal 10. To prepare for Classy's removal, JS files that
would otherwise be inherited from Classy were copied here.
