## Purpose of this folder
Icons in this folder are copied from Drupal core. This folder with its content
should be removed before moving Claro to Drupal core. See
https://www.drupal.org/project/claro/issues/3045216 for details.
